---
name: "study-train"
description: "Turn study material (photos, notes, PDFs, outlines, vocab lists) into a single-file HTML trainer that teaches every item forwards AND backwards, for cramming and long-term memory. Use instead of study-trainer."
---

# Study Train

Build one self-contained HTML study game from whatever the student uploads (textbook photo, worksheet, notes, PDF, reading outline, pasted list). Goals: the student knows **every item in both directions** (prompt → answer AND answer → explain it), understands each concept, can **cram** effectively the night before a quiz, and **keeps** it long term. The audience is a student: simple, warm, encouraging language.

## Learning science the design is built on (keep every one)

- **Retrieval practice / testing effect** (Roediger & Karpicke 2006; Dunlosky et al. 2013, "high utility"): recall from memory, never re-reading.
- **Bidirectional retrieval**: every item becomes TWO cards, forward (prompt → answer) and backward (answer → explain it). An item is mastered only when both cards are.
- **Pretesting effect** (Richland, Kornell & Kao 2009): guess before a new item is revealed (blank allowed).
- **Generation effect and desirable difficulty** (Slamecka & Graf 1978; Bjork 1994): recognition (multiple choice) → typed recall → typed recall with the section cue hidden.
- **Elaboration / self-explanation** (Chi 1994): backward cards are explained in the student's own words, graded by key ideas.
- **Elaborative interrogation**: every item shows a 🤔 "Why it matters" line; the intro links it to the unit's big question.
- **Immediate corrective feedback** (Metcalfe 2017): after any miss, show their answer next to the right one, then make them type it out (or re-explain with the key words).
- **Confidence / hypercorrection effect** (Butterfield & Metcalfe 2001): typed cards have "Sure" (Enter) and "Just guessing" (Shift+Enter). Correct guesses don't level up; confident errors get a ⚡ surprise-mistake message and return sooner.
- **Mnemonics** (keyword method, Atkinson & Raugh 1975) + **self-generated mnemonics**: every item has a 💡 hook; items missed 3+ times offer "write your own hook", saved and shown from then on.
- **Targeting confusions**: ⚠️ warnings for look-alikes; distractors are real look-alikes.
- **Spacing within a session** (Cepeda et al. 2006): misses return in 2-3 cards; gaps grow with level.
- **Adaptive spacing across days** (SM-2 / Anki-style): each mastered card has its own interval and ease, so easy cards spread out fast and hard ones come back sooner.
- **Successive relearning for cramming** (Rawson & Dunlosky): cram mode drills weakest-first until each card is right twice in a row while sure.
- **Sleep consolidation**: cram mode tells students to sleep after cramming and schedules a morning check of what they missed.
- **Interleaving** (Rohrer & Taylor 2007): mix items, units and directions; never the same card twice in a row.
- **Mastery learning** (Bloom): a perfect final test, both directions, unlocks the apply stage.
- **Transfer / Feynman teach-back**: apply questions answered "like teaching a friend who missed class", then compared with a model answer.
- **Motivation**: answer streak 🔥, best streak, daily study streak 📅, accuracy, split progress chips (left = forwards, right = backwards), toughest-items list, short celebrations.

In the reply, don't overclaim. Say the design uses "well-supported study techniques", not "guaranteed".

## Workflow

1. **Read the material.** View images with Read; extract text from PDFs and docs. If the material is only an outline of headings, fill in answers from reliable standard knowledge for that course/textbook and tell the student to check them against their notes. If something is ambiguous, ask one short question; otherwise proceed.
2. **Build the item deck.** Cover everything; skip nothing. Each item:
   - `u` unit/section id · `f` section heading (cue at levels 1-2, hidden at 3)
   - `q` a full, informative question; it doubles as the "full idea" on backward cards, so include who/what/where/why
   - `a` accepted answers (first = canonical; add synonyms, spellings, alternate names)
   - `h` vivid short memory hook · `d` optional why-it-matters line · `w` optional confusion warning
   - `mc` 3 plausible distractors (real look-alikes)
   - `k` optional key words for the backward card, only when `q` + `d` lack 3+ meaningful words
   Group by unit with title, page range, and the unit's main-point question. Item style by subject: vocab term ↔ meaning; science/history question → term or short fact; math problem → numeric answer (accept equivalents, fresh variant on retry when possible); processes as short typed sequences.
3. **Write apply items** (15-25): translation sentences with gloss (languages), word problems (math), or explain/compare questions with a ~30-45 word model answer and 3-4 key points (science/history). Self-graded; a miss means typing the model answer (≥80% word overlap), then it returns 3 cards later.
4. **Build the HTML** — one file, no external dependencies.
   - **Home:** unit picker (multi-select, progress bars), daily-streak pill, a 📅 test-date input that applies to the selected units, a "test tomorrow / in 2 days" banner with Cram button, a review banner when cards are due (or "next review in N days"), and buttons ⚡ Cram and Learn.
   - **Learn stages per selection:** Learn ⇄ → Final test → Apply → Hub (practice again, final test, apply, cram, other units).
   - **Cards:** `id|f` and `id|r`; active pool ≈ 10 cards.
   - **New item intro:** guess first → reveal answer, hook(s), why-it-matters, warning, unit main point, "you'll practice this both ways" → type it once. Both cards start at level 1; the backward card is inserted a few cards later.
   - **Levels:** 1 = multiple choice (number keys; backward = pick which question this answers), 2 = typed / explain, 3 = typed / explain with section cue hidden, 4 = mastered. Correct+sure → up a level; correct+guess → no change, back in 2-4; wrong → down a level (min 1) + correction; confident wrong → back in 1-2. Gaps: L1 2-3, L2 3-5, L3 6-9.
   - **Backward grading:** key words auto-derived from `q` + `d` (or `k`): drop stop words, short words, and the answer's own words; match by 5-letter stem with Levenshtein ≤1 typo tolerance for words ≥6 letters; need min(2, #keys). On success show their text, matched key words lit, and the full idea highlighted. On a miss show the full idea with key-word chips and require min(3, #keys) of them.
   - **Final test:** every card both directions, shuffled, no feedback; perfect score required; misses → fix screens → back to Learn at level 2.
   - **Long-term scheduler (SM-2 style):** per card `{ivl, ease, lapses, due}`. On mastery: ivl 1 day, ease 2.5 minus 0.15 per earlier miss (min 1.5). Review sure-correct: ivl 1 → 3 → round(ivl × ease × random 0.95-1.05), ease +0.05 (max 3.0). Guess-correct: ivl × 1.2, ease −0.15. Miss: lapses+1, ease −0.2 (min 1.3), ivl 1, re-asked later the same session without advancing. Cap 365 days. Due times are day-aligned (4 am local) so cards are due all day.
   - **Test date:** stored with the units it covers. Any of those cards whose due date would fall after the day before the test is pulled in to that day (only when that day is still in the future). Setting a test date re-clamps existing schedules.
   - **Review sessions:** up to 60 due cards, most at-risk first (test units, most overdue relative to interval, lowest ease) but interleaved; all typed/explain with confidence; "review N more" when more are due.
   - **Cram mode:** for the selected units, choose "weakest 40" or all cards, sorted by weakness (not yet mastered, lapses, low ease, misses). Unlearned items get a quick intro first. Typed/explain only. Each card must be right twice in a row while sure; a sure-correct reinserts 5-8 cards later, a guess resets the run and reinserts 3-5, a miss resets the run, records a lapse for scheduled cards (due next morning), corrects, and reinserts 2-3. Cards completed in cram that weren't mastered become mastered and scheduled. Show tips: short bursts, sleep after, morning check.
   - **Forward answer checking:** lowercase, strip accents/punctuation, strip leading "to/the/a/an/i"; split on , ; / "or"; Levenshtein tolerance 0 / 1 / 2 for answers <5 / 5-8 / 9+ characters. Numbers must match exactly. Reject negation flips (in/un/non/im/il/ir). Accept the answer inside a slightly longer phrase (≤3 extra words) only for answers ≥4 characters.
   - **HUD:** cards mastered, streak, best, accuracy; split chip grid with legend; 📖 item list with hooks (hidden in tests); reset-selection with confirm.
   - **⚙️ Backup & settings:** export progress as a copyable code (base64 JSON tagged with the storage key), import from a code (reject invalid or wrong-subject codes with a friendly error), erase all with confirm.
   - **Progress:** localStorage with every read/write in try/catch; unique storage key per subject; migrate older saved schedules on load.
   - **Style:** warm, clean CSS variables, dark mode via prefers-color-scheme, mobile-friendly with 16px side padding, Enter to submit/continue everywhere. Title the page after the subject.
5. **Test before delivering.** `node --check` the script. Per item: canonical answer matches itself, no distractor is accepted, ≥2 backward key words, junk text ("the a it was") scores zero. In jsdom with a mocked clock: full Learn → Final test (with misses, then perfect) → Apply → Hub for one unit, several, and all; a cram night on never-learned material (with leech hooks) followed by the morning check; ~120 simulated days of reviews confirming intervals grow and nothing gets stuck; test-date clamping (no test-unit card due after the day before the test); export → import into a fresh page and a rejected bad code. No errors, no stuck screens.
6. **Deliver.** Send the .html file and write 2-4 short lines on how to use it (learn nightly, review when due, cram before quizzes, back up with ⚙️). Point out anything you weren't sure about or filled in from outside the material. Don't recap the build steps.