---
name: study-train
description: Turn study material (photos, notes, PDFs, outlines, vocab lists) into a colorful single-file HTML trainer that teaches every item forwards AND backwards, with arcade modes, XP and celebrations, for cramming and long-term memory.
---

# Study Train

Build one self-contained HTML study game from whatever the student uploads (textbook photo, worksheet, notes, PDF, reading outline, pasted list). Goals: the student knows **every item in both directions** (prompt → answer AND answer → explain it), understands each concept, can **cram** effectively the night before a quiz, **keeps** it long term, and **wants to come back** because studying feels fun and rewarding. The audience is a student: simple, warm, encouraging language.

## Start from the template (do this first)

The look, the arcade modes, the celebrations and all the study logic already exist in a tested reference trainer. Reuse it instead of rewriting it:

1. Use `template.html` from this skill's folder if it is there. Otherwise get it from GitHub: `git clone --depth 1 https://github.com/henryprice1/Claude-Study-Skill` and use `latin-example.html`. Only if both fail, build from the spec below.
2. Copy it, then replace **only** the subject data and theme constants:
   - `<title>`, the `<h1>`, `SUBJECT`, and a new unique `KEY` (storage key) for this subject.
   - `UNITS`, `VOCAB` (term ↔ meaning items) and/or `GRAMMAR` (explain items), `SENTENCES` / `GAPPLY` (apply items). For non-language subjects, put question → answer items in `GRAMMAR`-style objects and leave `VOCAB` and `SENTENCES` empty.
   - Theme constants: `RANKS` (10 level titles themed to the subject, e.g. biology: Cell → Tissue → Organ → … → Ecosystem), `FLOATERS` (10-14 background symbols for the subject, e.g. chemistry: H, O, ⚛, Δ), `BOSS` (an emoji + a fun name tied to the subject), and the `CHEERS` list (one or two subject-flavored cheers are fine).
   - Labels that say "Latin" (prompt labels, flashcard "…in Latin?" hint, the `📖 Word list` button) → the subject's wording.
3. Don't change the engine (scheduling, grading, rewards, arcade) unless the material truly needs it. Then run the tests in step 5.

## Learning science the design is built on (keep every one)

- **Retrieval practice / testing effect** (Roediger & Karpicke 2006; Dunlosky et al. 2013, "high utility"): recall from memory, never re-reading.
- **Bidirectional retrieval**: every item becomes TWO cards, forward (prompt → answer) and backward (answer → explain it). An item is mastered only when both cards are.
- **Pretesting effect** (Richland, Kornell & Kao 2009): guess before a new item is revealed (blank allowed).
- **Generation effect and desirable difficulty** (Slamecka & Graf 1978; Bjork 1994): recognition (multiple choice) → typed recall → typed recall with the section cue hidden.
- **Elaboration / self-explanation** (Chi 1994): backward cards are explained in the student's own words, graded by key ideas.
- **Elaborative interrogation**: every item shows a 🤔 "Why it matters" line; the intro links it to the unit's big question.
- **Immediate corrective feedback** (Metcalfe 2017): after any miss, show their answer next to the right one, then make them type it out (or re-explain with the key words).
- **Confidence / hypercorrection effect** (Butterfield & Metcalfe 2001): typed cards have "Sure" (Enter) and "Just guessing" (Shift+Enter). Correct guesses don't level up; confident errors get a ⚡ surprise-mistake message and return sooner.
- **Mnemonics** (keyword method, Atkinson & Raugh 1975) + **self-generated mnemonics**: every item has a 💡 hook; items missed 3+ times offer "write your own hook", saved and shown from then on.
- **Targeting confusions**: ⚠️ warnings for look-alikes; distractors are real look-alikes.
- **Spacing within a session** (Cepeda et al. 2006): misses return in 2-3 cards; gaps grow with level.
- **Adaptive spacing across days** (SM-2 / Anki-style): each mastered card has its own interval and ease, so easy cards spread out fast and hard ones come back sooner.
- **Successive relearning for cramming** (Rawson & Dunlosky): cram mode drills weakest-first until each card is right twice in a row while sure.
- **Sleep consolidation**: cram mode tells students to sleep after cramming and schedules a morning check of what they missed.
- **Interleaving** (Rohrer & Taylor 2007): mix items, units and directions; never the same card twice in a row.
- **Mastery learning** (Bloom): a perfect final test, both directions, unlocks the apply stage.
- **Transfer / Feynman teach-back**: apply questions answered "like teaching a friend who missed class", then compared with a model answer.
- **Motivation and game elements** (gamification meta-analysis, Sailer & Homner 2020: small positive effects on learning, larger on motivation): XP and levels, streak milestones, a daily goal, badges, celebrations, and arcade modes that are still retrieval practice underneath. Rewards always follow real recall, never just clicking.

In the reply, don't overclaim. Say the design uses "well-supported study techniques", not "guaranteed".

## Workflow

1. **Read the material.** View images with Read; extract text from PDFs and docs. If the material is only an outline of headings, fill in answers from reliable standard knowledge for that course/textbook and tell the student to check them against their notes. If something is ambiguous, ask one short question; otherwise proceed.
2. **Build the item deck.** Cover everything; skip nothing. Each item:
   - `u` unit/section id · `f` section heading (cue at levels 1-2, hidden at 3)
   - `q` a full, informative question; it doubles as the "full idea" on backward cards, so include who/what/where/why
   - `a` accepted answers (first = canonical; add synonyms, spellings, alternate names)
   - `h` vivid short memory hook · `d` optional why-it-matters line · `w` optional confusion warning
   - `mc` 3 plausible distractors (real look-alikes)
   - `k` optional key words for the backward card, only when `q` + `d` lack 3+ meaningful words
   Group by unit with title, page range, and the unit's main-point question. Item style by subject: vocab term ↔ meaning; science/history question → term or short fact; math problem → numeric answer (accept equivalents, fresh variant on retry when possible); processes as short typed sequences. Keep forward answers short (they also appear on Match tiles and multiple-choice buttons).
3. **Write apply items** (15-25): translation sentences with gloss (languages), word problems (math), or explain/compare questions with a ~30-45 word model answer and 3-4 key points (science/history). Self-graded; a miss means typing the model answer (≥80% word overlap), then it returns 3 cards later.
4. **Build the HTML** from the template (see the top). One file; the only external resource is the Google Fonts stylesheet (Fredoka + Nunito), with system-font fallbacks so it works offline. The spec, so you can check or rebuild it:
   - **Home:** goal ring (today's correct answers vs `GOAL` = 20), pills (daily streak, best, badge count), unit picker (multi-select, progress bars, 👑 on mastered units), a 📅 test-date input that applies to the selected units, a "test tomorrow / in 2 days" banner with Cram button, a review banner when cards are due (or "next review in N days"), buttons Learn ⇄ and ⚡ Cram, then a 🎮 **Arcade** grid of colorful mode tiles showing each mode's personal best for the current selection.
   - **Learn stages per selection:** Learn ⇄ → Final test → Apply → Hub (practice again, final test, apply, cram, other units).
   - **Cards:** `id|f` and `id|r`; active pool ≈ 10 cards.
   - **New item intro:** guess first → reveal answer, hook(s), why-it-matters, warning, unit main point, "you'll practice this both ways" → type it once. Both cards start at level 1; the backward card is inserted a few cards later.
   - **Levels:** 1 = multiple choice (number keys; backward = pick which question this answers), 2 = typed / explain, 3 = typed / explain with section cue hidden, 4 = mastered. Correct+sure → up a level; correct+guess → no change, back in 2-4; wrong → down a level (min 1) + correction; confident wrong → back in 1-2. Gaps: L1 2-3, L2 3-5, L3 6-9.
   - **Backward grading:** key words auto-derived from `q` + `d` (or `k`): drop stop words, short words, and the answer's own words; match by 5-letter stem with Levenshtein ≤1 typo tolerance for words ≥6 letters; need min(2, #keys). On success show their text, matched key words lit, and the full idea highlighted. On a miss show the full idea with key-word chips and require min(3, #keys) of them.
   - **Final test:** every card both directions, shuffled, no feedback (no sounds, pop-ups or celebrations while it runs; badges and level-ups earned during it are held and shown on the results screen); perfect score required; misses → fix screens → back to Learn at level 2.
   - **Long-term scheduler (SM-2 style):** per card `{ivl, ease, lapses, due}`. On mastery: ivl 1 day, ease 2.5 minus 0.15 per earlier miss (min 1.5). Review sure-correct: ivl 1 → 3 → round(ivl × ease × random 0.95-1.05), ease +0.05 (max 3.0). Guess-correct: ivl × 1.2, ease −0.15. Miss: lapses+1, ease −0.2 (min 1.3), ivl 1, re-asked later the same session without advancing. Cap 365 days. Due times are day-aligned (4 am local) so cards are due all day.
   - **Test date:** stored with the units it covers. Any of those cards whose due date would fall after the day before the test is pulled in to that day (only when that day is still in the future). Setting a test date re-clamps existing schedules.
   - **Review sessions:** up to 60 due cards, most at-risk first (test units, most overdue relative to interval, lowest ease) but interleaved; all typed/explain with confidence; "review N more" when more are due.
   - **Cram mode:** for the selected units, choose "weakest 40" or all cards, sorted by weakness (not yet mastered, lapses, low ease, misses). Unlearned items get a quick intro first. Typed/explain only. Each card must be right twice in a row while sure; a sure-correct reinserts 5-8 cards later, a guess resets the run and reinserts 3-5, a miss resets the run, records a lapse for scheduled cards (due next morning), corrects, and reinserts 2-3. Cards completed in cram that weren't mastered become mastered and scheduled. Show tips: short bursts, sleep after, morning check.
   - **Forward answer checking:** lowercase, strip accents/punctuation, strip leading "to/the/a/an/i"; split on , ; / "or"; Levenshtein tolerance 0 / 1 / 2 for answers <5 / 5-8 / 9+ characters. Numbers must match exactly. Reject negation flips (in/un/non/im/il/ir). Accept the answer inside a slightly longer phrase (≤3 extra words) only for answers ≥4 characters. An answer that exactly equals another item's answer is a look-alike, not a typo.
   - **HUD:** level badge + rank title + animated XP bar; colored stat pills (🔥 streak, which pops when it grows; 🏅 best; 🎯 accuracy; ⭐ cards mastered); split chip grid with legend (left = forwards, right = backwards); 📖 item list with hooks (hidden in the final test and arcade games); 🏅 Badges sheet; 🔊 sound toggle; reset-selection with confirm.
   - **⚙️ Backup & settings:** export progress as a copyable code (base64 JSON tagged with the storage key), import from a code (reject invalid or wrong-subject codes with a friendly error), erase all with confirm.
   - **Progress:** localStorage with every read/write in try/catch; unique storage key per subject; migrate older saves on load (missing fields filled from a fresh state, so new features never wipe progress).

   **Fun layer (keep it all; this is what makes students come back):**
   - **Look:** bright and colorful. Animated background of 4 large blurred gradient blobs slowly drifting, a soft dot grid, and the subject's `FLOATERS` drifting upward at low opacity. Glassy cards (translucent, backdrop blur) with a rainbow top edge, gradient headings and prompts, gradient primary buttons that lift on hover and squish on press, numbered multiple-choice buttons with a different color per option, colorful stat pills. Light theme = pastel; dark theme = deep night with neon blobs (prefers-color-scheme, with `:root[data-theme]` overrides). Mobile-friendly with 16px side padding and no horizontal scroll. Respect `prefers-reduced-motion` (no drifting, few particles).
   - **Animations:** every screen pops in; right answers bounce, wrong ones shake; the card shakes when you lose a life or the boss hits you.
   - **Confetti engine:** one full-screen canvas with particle bursts (rectangles, dots, stars). Small burst on a mastered item, side cannons for milestones, fireworks for big wins.
   - **XP and levels:** +5 XP per correct answer, +2 per 5-answer combo (max +10); +15 per card mastered, +25 more when both directions are mastered, +100 per unit mastered, +200 for a perfect final test, +50 for finishing Apply, a cram session or the daily goal, +20 per review session, +100 for beating the boss. Level L needs 150·(L−1)·L total XP (300, 900, 1800, 3000…), so one unit takes a student to about level 4-5. A level-up opens a modal (spinning rainbow ring, the new `RANKS` title, fireworks); Enter or the button closes it. A floating "+N XP" pops by the card on each answer.
   - **Streak milestones:** at 5, 10, 15, 20, 25, 30, 40, 50, 75, 100 (then every 25) in a row: giant gradient banner text ("⚡ 10 streak! On fire!"), screen-edge glow, confetti and a fanfare.
   - **Mastery moments:** "⭐ Mastered both ways!" toast with a star burst when an item's two cards are mastered; "🏛️ Unit mastered!" banner + fireworks + toast the first time every card in a unit is mastered.
   - **Daily goal:** ring on Home fills toward `GOAL` correct answers today; hitting it gives a toast, fireworks and +50 XP, and the ring glows.
   - **Badges (17):** first steps, both ways, unit conquered, flawless (perfect test), 10/25/50 streak, daily goal, 3- and 7-day study streaks, cram finished, 10 mistakes fixed, Speed Round 30+, Match under 40 s, Survival 25, boss defeated, level 5. Unlocks show a gold toast with a chime; the Badges sheet shows earned ones in color and locked ones in grey.
   - **Sound:** tiny Web Audio synth, no files: rising two-note chime for correct (pitch climbs with the combo), soft low tone for wrong, arpeggio for stars and badges, fanfare for big wins. On by default, 🔊 toggle saved. Create the audio context only after the first click or key press.
   - **Arcade modes** (all use the selected units, give XP, count toward streaks and the daily goal, and save a personal best per unit selection; they never change the review schedule):
     - ⏱️ **Speed Round:** 60-second timer bar; multiple choice in both directions; every 5 in a row raises the ×multiplier (max ×4); a wrong answer costs 3 seconds.
     - 🧩 **Match:** 6 random items become 12 tiles (term and meaning); tap two to pair them; matched pairs burst and fade; counting-up timer; best = fastest time.
     - 🛡️ **Survival:** typed answers, 3 hearts, every 10 right earns a heart (max 5); after a miss the right answer is shown above the next card.
     - `BOSS` **Boss Battle:** a boss built from the student's 6 toughest items (most misses, lowest levels), both directions. HP bar = remaining cards × 10; each right answer hits it (−10 damage number, flinch, sparks); each wrong answer costs a heart, shows the right answer and brings that card back 2-3 later. Win = fireworks, badge, +100 XP; lose = friendly rematch screen.
     - 🃏 **Flashcards:** 3D flip cards (tap or Space), both directions with the hook on the back; "Knew it" (1) / "Not yet" (2), and "not yet" cards come back 3-5 cards later until known.
   - Results screens for every mode show the score, "New personal best!" with fireworks when beaten, and Play again (Enter) / Home.
5. **Test before delivering.** `node --check` the script. Per item: canonical answer matches itself, no distractor is accepted, ≥2 backward key words, junk text ("the a it was") scores zero. In jsdom (pretendToBeVisual, timers shortened, mocked clock): full Learn → Final test (with misses, then perfect) → Apply → Hub for one unit, several, and all; every arcade mode played to its end screen (Speed by running the timer out, Match with a mismatch, Survival until game over, Boss both win and lose, Flashcards with some "not yet"); a cram night on never-learned material (with leech hooks) followed by the morning check; ~120 simulated days of reviews confirming intervals grow and nothing gets stuck; test-date clamping (no test-unit card due after the day before the test); level-up modal closes on Enter; no sounds, pop-ups or celebrations during the final test; export → import into a fresh page and a rejected bad code. No errors, no stuck screens. Then take Playwright screenshots of Home, a card, a milestone moment and two arcade modes in light and dark, at desktop and 390px width, and look at them: text readable over the background, nothing overlapping or cut off, no horizontal scroll.
6. **Deliver.** Send the .html file and write 2-4 short lines on how to use it (learn nightly, review when due, cram before quizzes, play the arcade for extra practice, back up with ⚙️). Point out anything you weren't sure about or filled in from outside the material. Don't recap the build steps.
